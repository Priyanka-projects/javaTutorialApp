import 'dart:ui';

const background = Color.fromRGBO(130, 2, 109, 0.43529411764705883);