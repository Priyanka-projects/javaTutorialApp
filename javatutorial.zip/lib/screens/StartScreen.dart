import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:javatutorial/constants.dart';

class StartScreen extends StatefulWidget{
  @override
  _StartScreenState createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {
  @override
  Widget build(BuildContext context) {
  return Scaffold(
    backgroundColor: background,
    body: Stack(

    ),
  );
  }
}